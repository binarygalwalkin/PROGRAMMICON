﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arena
{
    /*
     *       _____ _____ _____                _       _
     *      |_   _/  __ \_   _|              (_)     | |
     *        | | | /  \/ | |  ___  ___   ___ _  __ _| |
     *        | | ||      | | / __|/ _ \ / __| |/ _` | |
     *       _| |_| \__/\ | |_\__ \ (_) | (__| | (_| | |
     *      |_____\_____/ |_(_)___/\___/ \___|_|\__,_|_|
     *                   ___
     *                  |  _|___ ___ ___
     *                  |  _|  _| -_| -_|  LICENCE
     *                  |_| |_| |___|___|
     *
     * IT NEWS  <>  PROGRAMMING  <>  HW & SW  <>  COMMUNITY
     *
     * This source code is part of online courses at IT social
     * network WWW.ICT.SOCIAL
     *
     * Feel free to use it for whatever you want, modify it and share it but
     * don't forget to keep this link in code.
     *
     * For more information visit http://www.ict.social/licences
     */
    class Program
    {
        static void Main(string[] args)
        {
            // Create instances
            Dice sixSided = new Dice();
            Dice tenSided = new Dice(10);

            // Roll 6-sided dice
            Console.WriteLine(sixSided);
            for (int i = 0; i < 10; i++)
                Console.Write(sixSided.Roll() + " ");

            // Roll 10-sided dice
            Console.WriteLine("\n\n" + tenSided);
            for (int i = 0; i < 10; i++)
                Console.Write(tenSided.Roll() + " ");

            Console.ReadKey();
        }
    }
}
