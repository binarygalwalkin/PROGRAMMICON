﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListLottery
{
    /*
     *       _____ _____ _____                _       _
     *      |_   _/  __ \_   _|              (_)     | |
     *        | | | /  \/ | |  ___  ___   ___ _  __ _| |
     *        | | ||      | | / __|/ _ \ / __| |/ _` | |
     *       _| |_| \__/\ | |_\__ \ (_) | (__| | (_| | |
     *      |_____\_____/ |_(_)___/\___/ \___|_|\__,_|_|
     *                   ___
     *                  |  _|___ ___ ___
     *                  |  _|  _| -_| -_|  LICENCE
     *                  |_| |_| |___|___|
     *
     * IT NEWS  <>  PROGRAMMING  <>  HW & SW  <>  COMMUNITY
     *
     * This source code is part of online courses at IT social
     * network WWW.ICT.SOCIAL
     *
     * Feel free to use it for whatever you want, modify it and share it but
     * don't forget to keep this link in code.
     *
     * For more information visit http://www.ict.social/licences
     */

    /// <summary>
    /// Represents lottery which generates and stores random numbers
    /// </summary>
    class Lottery
    {
        /// <summary>
        /// Stored generated numbers
        /// </summary>
        private List<int> numbers;
        /// <summary>
        /// Random number generator instance
        /// </summary>
        private Random random;

        /// <summary>
        /// Initializes instance
        /// </summary>
        public Lottery()
        {
            random = new Random();
            numbers = new List<int>();
        }

        /// <summary>
        /// Generates and stores new random number
        /// </summary>
        /// <returns>Newly generated number</returns>
        public int Lot()
        {
            int number = random.Next(100) + 1;
            numbers.Add(number);
            return number;
        }

        /// <summary>
        /// Returns stored generated numbers as string
        /// </summary>
        /// <returns>Stored generated numbers as string</returns>
        public string Print()
        {
            string s = "";
            numbers.Sort();
            foreach (int i in numbers)
                s += i + " ";
            return s;
        }

    }
}
