﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListLottery
{
    class Program
    {
        /*
         *       _____ _____ _____                _       _
         *      |_   _/  __ \_   _|              (_)     | |
         *        | | | /  \/ | |  ___  ___   ___ _  __ _| |
         *        | | ||      | | / __|/ _ \ / __| |/ _` | |
         *       _| |_| \__/\ | |_\__ \ (_) | (__| | (_| | |
         *      |_____\_____/ |_(_)___/\___/ \___|_|\__,_|_|
         *                   ___
         *                  |  _|___ ___ ___
         *                  |  _|  _| -_| -_|  LICENCE
         *                  |_| |_| |___|___|
         *
         * IT NEWS  <>  PROGRAMMING  <>  HW & SW  <>  COMMUNITY
         *
         * This source code is part of online courses at IT social
         * network WWW.ICT.SOCIAL
         *
         * Feel free to use it for whatever you want, modify it and share it but
         * don't forget to keep this link in code.
         *
         * For more information visit http://www.ict.social/licences
         */

        // Simple lottery simulator using List collection
        static void Main(string[] args)
        {
            string[] stringArray = { "First", "Second", "Third" };
            List<string> l = new List<string>(stringArray);
            Console.WriteLine(l[2]);

            Lottery lottery = new Lottery();
            Console.WriteLine("Welcome to lottery program.");
            char choice = '0';
            // main loop
            while (choice != '3')
            {
                // option list
                Console.WriteLine("1 - Lot the next number");
                Console.WriteLine("2 - Print numbers");
                Console.WriteLine("3 - Quit");
                choice = Console.ReadKey().KeyChar;
                Console.WriteLine();
                // reaction to choice
                switch (choice)
                {
                    case '1':
                        Console.WriteLine("The drew number: {0}", lottery.Lot());
                        break;
                    case '2':
                        Console.WriteLine("Drew numbers: {0}", lottery.Print());
                        break;
                    case '3':
                        Console.WriteLine("Thanks for using the program");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please, try again.");
                        break;
                }
            }
        }
    }
}
